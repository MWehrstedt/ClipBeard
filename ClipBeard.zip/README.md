## ClipBeard

A small Browser Extension to save frequently used texts ready to use for your pasting pleasure.

[A roadmap is found here](#)

