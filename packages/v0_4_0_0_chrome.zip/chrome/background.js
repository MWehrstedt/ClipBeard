/* For Jenny, my Queen */

/*  ============================
    Background script file, handles context menu items
    ============================ */
chrome.browserAction.setBadgeBackgroundColor({ color: '#007f00' });

// Create context menu items
chrome.contextMenus.create({
    id: 'clipbeardSelectionMenuItem',
    title: chrome.i18n.getMessage('contextMenuLabel'),
    contexts: ["selection"],
}, function () {
    // onCreated function. 
});

chrome.contextMenus.onClicked.addListener(function (info, tab) {
    // Check for contextmenu item click
    if (info.menuItemId === 'clipbeardSelectionMenuItem') {
        var snippetText = info.selectionText;
        var snippetHeader = new Date().toUTCString();

        // Iterate through every storage entry and show badge, if snippet is already saved
        var storageItems = chrome.storage.sync.get(function (items) {
            for (var element in items) {
                if (items[element] === snippetText) {

                    // Show a star character (unicode u+2605) on an orange background
                    chrome.browserAction.setBadgeText({ text: String.fromCharCode(9733) });
                    chrome.browserAction.setBadgeBackgroundColor({color: "#FFA500"});
                    return;
                }
            }

            // Show a plus on a green background
            chrome.storage.sync.set({ [snippetHeader]: snippetText });
            chrome.browserAction.setBadgeBackgroundColor({color: "#00CC00"});
            chrome.browserAction.setBadgeText({ text: '+' });
        });


        setTimeout(function () {
            chrome.browserAction.setBadgeText({ text: "" });
        }, 300000);
    }
});
